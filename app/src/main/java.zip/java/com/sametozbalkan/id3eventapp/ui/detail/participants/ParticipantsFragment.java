package com.sametozbalkan.id3eventapp.ui.detail.participants;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.sametozbalkan.id3eventapp.R;
import com.sametozbalkan.id3eventapp.databinding.FragmentParticipantsBinding;

import java.util.ArrayList;

public class ParticipantsFragment extends Fragment {

    private FragmentParticipantsBinding binding;
    private ParticipantsAdapter adapter;
    private ParticipantsViewModel viewModel;

    public ParticipantsFragment() {
        super(R.layout.fragment_participants);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentParticipantsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this)
                .get(ParticipantsViewModel.class);

        adapter = new ParticipantsAdapter(new ArrayList<>());
        binding.rvParticipants.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );
        binding.rvParticipants.setAdapter(adapter);

        observeParticipants();
        setupSearch();
    }

    private void observeParticipants() {
        viewModel.getParticipants().observe(
                getViewLifecycleOwner(),
                participants -> adapter.updateList(participants)
        );
    }

    private void setupSearch() {
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                viewModel.filter(s.toString());
            }

            @Override public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
