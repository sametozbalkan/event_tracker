package com.sametozbalkan.id3eventapp.ui.detail.participants;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ParticipantsViewModel extends ViewModel {

    private final List<Participant> allParticipants = new ArrayList<>();
    private final MutableLiveData<List<Participant>> participantsLiveData =
            new MutableLiveData<>();

    public ParticipantsViewModel() {
        loadParticipants();
        showAll();
    }

    public LiveData<List<Participant>> getParticipants() {
        return participantsLiveData;
    }

    private void loadParticipants() {
        allParticipants.addAll(Arrays.asList(
                new Participant("Alice Johnson", "Organizer", "https://i.pravatar.cc/150?img=1"),
                new Participant("Bob Smith", "Speaker", "https://i.pravatar.cc/150?img=2"),
                new Participant("Charlie Brown", "Attendee", "https://i.pravatar.cc/150?img=3"),
                new Participant("David Miller", "Speaker", "https://i.pravatar.cc/150?img=4")
        ));
    }

    public void showAll() {
        participantsLiveData.setValue(new ArrayList<>(allParticipants));
    }

    public void filter(String query) {
        if (query == null || query.trim().isEmpty()) {
            showAll();
            return;
        }

        String q = query.toLowerCase();
        List<Participant> filtered = new ArrayList<>();

        for (Participant p : allParticipants) {
            if (p.getName().toLowerCase().contains(q) ||
                    p.getRole().toLowerCase().contains(q)) {
                filtered.add(p);
            }
        }

        participantsLiveData.setValue(filtered);
    }
}
