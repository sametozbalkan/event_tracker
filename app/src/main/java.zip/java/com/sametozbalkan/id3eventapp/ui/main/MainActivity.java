package com.sametozbalkan.id3eventapp.ui.main;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.sametozbalkan.id3eventapp.R;
import com.sametozbalkan.id3eventapp.adapter.EventAdapter;
import com.sametozbalkan.id3eventapp.databinding.ActivityMainBinding;
import com.sametozbalkan.id3eventapp.model.Event;
import com.sametozbalkan.id3eventapp.model.EventType;
import com.sametozbalkan.id3eventapp.ui.detail.EventDetailActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private EventAdapter adapter;
    private MainViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        setupRecyclerView();
        setupChips();
        observeEvents();
    }

    private void setupRecyclerView() {
        binding.rvEvents.setLayoutManager(new LinearLayoutManager(this));

        adapter = new EventAdapter(new ArrayList<>(), event ->
                startActivity(new Intent(this, EventDetailActivity.class))
        );

        binding.rvEvents.setAdapter(adapter);
    }

    private void observeEvents() {
        viewModel.getEvents().observe(this, events -> {
            adapter.updateData(events);
        });
    }

    private void setupChips() {
        binding.chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;

            int id = checkedIds.get(0);

            if (id == R.id.chipAll) {
                viewModel.showAll();
            } else if (id == R.id.chipToday) {
                viewModel.filterByType(EventType.TODAY);
            } else if (id == R.id.chipUpcoming) {
                viewModel.filterByType(EventType.UPCOMING);
            } else if (id == R.id.chipPast) {
                viewModel.filterByType(EventType.PAST);
            }
        });
    }
}
