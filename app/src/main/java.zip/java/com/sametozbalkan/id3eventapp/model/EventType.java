package com.sametozbalkan.id3eventapp.model;

public enum EventType {
    TODAY,
    UPCOMING,
    PAST
}