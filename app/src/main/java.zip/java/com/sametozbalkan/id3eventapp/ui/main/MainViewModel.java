package com.sametozbalkan.id3eventapp.ui.main;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.sametozbalkan.id3eventapp.model.Event;
import com.sametozbalkan.id3eventapp.model.EventType;

import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends ViewModel {

    private final List<Event> allEvents = new ArrayList<>();
    private final MutableLiveData<List<Event>> eventsLiveData = new MutableLiveData<>();

    public MainViewModel() {
        loadEvents();
        showAll();
    }

    public LiveData<List<Event>> getEvents() {
        return eventsLiveData;
    }

    private void loadEvents() {
        allEvents.add(new Event(
                "Global Tech Summit 2024",
                "Annual gathering of tech leaders discussing AI.",
                "https://picsum.photos/800/400?1",
                "2h ago",
                "OCT 24",
                EventType.TODAY,
                false
        ));

        allEvents.add(new Event(
                "Local Charity Marathon",
                "Join the community for a 5k run.",
                "https://picsum.photos/800/400?2",
                "5h ago",
                "OCT 25",
                EventType.UPCOMING,
                false
        ));

        allEvents.add(new Event(
                "Modern Art Exhibition",
                "Contemporary digital art showcase.",
                "https://picsum.photos/800/400?3",
                "1d ago",
                "OCT 20",
                EventType.PAST,
                true
        ));
    }

    public void showAll() {
        eventsLiveData.setValue(new ArrayList<>(allEvents));
    }

    public void filterByType(EventType type) {
        List<Event> filtered = new ArrayList<>();
        for (Event event : allEvents) {
            if (event.getType() == type) {
                filtered.add(event);
            }
        }
        eventsLiveData.setValue(filtered);
    }
}

