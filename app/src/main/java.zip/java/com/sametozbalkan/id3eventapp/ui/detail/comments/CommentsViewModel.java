package com.sametozbalkan.id3eventapp.ui.detail.comments;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class CommentsViewModel extends ViewModel {

    private final MutableLiveData<List<Comment>> commentsLiveData =
            new MutableLiveData<>();

    private final List<Comment> comments = new ArrayList<>();

    public CommentsViewModel() {
        loadInitialComments();
    }

    public LiveData<List<Comment>> getComments() {
        return commentsLiveData;
    }

    private void loadInitialComments() {
        comments.add(new Comment(
                "Alex Rivera",
                "Can't wait for this! The lineup looks incredible.",
                "2m ago",
                12,
                new Comment(
                        "Event Team",
                        "Thanks Alex! See you there 🙌",
                        "1m ago",
                        3
                )
        ));

        comments.add(new Comment(
                "mert",
                "Will the keynote be streamed online?",
                "12m ago",
                5
        ));

        comments.add(new Comment(
                "selin",
                "Last year's event was amazing 🔥",
                "1h ago",
                21
        ));

        comments.add(new Comment(
                "kerem",
                "Any agenda PDF available?",
                "3h ago",
                2
        ));

        commentsLiveData.setValue(new ArrayList<>(comments));
    }

    public void addComment(String message) {
        comments.add(
                new Comment("You", message, "Just now", 0)
        );
        commentsLiveData.setValue(new ArrayList<>(comments));
    }
}
